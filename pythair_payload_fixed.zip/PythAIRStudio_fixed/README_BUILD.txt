PYTHAIR STUDIO STARTER
======================

What this starter does right now
--------------------------------
- Native Android app with Kotlin + Jetpack Compose UI.
- Embedded Python runtime through Chaquopy.
- Runs normal pure-Python scripts inside the app.
- Compiles PythAIR into a preview tree and can open browser targets.
- Compiles AIR and shows tokens/AST/validation JSON.
- Includes a browser tab using Android WebView.
- Has a single backend switch point in BrowserBackendConfig.kt.

Important truth
---------------
This starter does NOT magically run every desktop Python package unchanged.
It is realistic for pure Python, your own runtime code, and selected packaged modules.
Desktop GUI libs like Tkinter/PyQt are not part of this Android starter runtime.

How to build
------------
1. Open the folder in Android Studio.
2. Let Gradle sync and download dependencies.
3. Build the app.
4. Run on an Android device or emulator.

Backend switch
--------------
Open:
app/src/main/java/com/prad/pythairstudio/BrowserBackendConfig.kt

Near the bottom of that file you will see:
val BROWSER_BACKEND = "android_webview"

That is the single easy switch point.
In this starter, only android_webview is implemented.
You can later add chromium or another backend behind the same switch.

Project storage
---------------
Saved scripts are stored in the app's internal files/projects folder.
