# Keep Chaquopy bootstrap classes.
-keep class com.chaquo.python.** { *; }
-dontwarn com.chaquo.python.**
