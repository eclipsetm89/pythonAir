package com.prad.pythairstudio.ui.theme

import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF0B1220)
val SurfaceDark = Color(0xFF10192B)
val SurfaceAlt = Color(0xFF16233A)
val Accent = Color(0xFF60A5FA)
val TextMain = Color(0xFFF8FBFF)
