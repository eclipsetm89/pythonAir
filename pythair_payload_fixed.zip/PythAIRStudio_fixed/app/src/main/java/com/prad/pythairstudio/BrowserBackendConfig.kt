package com.prad.pythairstudio

// Keep the backend switch near the bottom of this file so it's easy to change later.
// Valid names for your architecture: android_webview, chromium, webview2.
// In this Android starter, only android_webview is implemented.

val BROWSER_BACKEND = "android_webview"
