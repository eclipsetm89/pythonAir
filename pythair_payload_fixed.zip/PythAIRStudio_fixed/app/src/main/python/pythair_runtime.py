from __future__ import annotations

import json
from dataclasses import dataclass, field

@dataclass
class Node:
    type: str
    name: str | None = None
    text: str | None = None
    action: str | None = None
    children: list["Node"] = field(default_factory=list)

    def to_dict(self):
        return {
            "type": self.type,
            "name": self.name,
            "text": self.text,
            "action": self.action,
            "children": [c.to_dict() for c in self.children],
        }

class PythAIRRuntimeError(Exception):
    pass

class PythAIRParser:
    def parse(self, script: str):
        items = []
        for raw in script.splitlines():
            line = raw.rstrip()
            if not line.strip() or line.lstrip().startswith("#"):
                continue
            indent = len(line) - len(line.lstrip(" "))
            items.append((indent, line.strip()))
        return items

    def build_tree(self, script: str):
        lines = self.parse(script)
        root = Node("root", text="PythAIR")
        stack: list[tuple[int, Node]] = [(-1, root)]
        browser_url: str | None = None
        macros = {}
        i = 0
        while i < len(lines):
            indent, line = lines[i]
            if line.startswith("do ") and line.endswith(":"):
                name = line[3:-1].strip()
                body = []
                i += 1
                while i < len(lines):
                    _, inner = lines[i]
                    if inner == "end":
                        break
                    body.append(inner)
                    i += 1
                macros[name] = body
                i += 1
                continue

            while stack and indent <= stack[-1][0]:
                stack.pop()
            parent = stack[-1][1]

            if line.startswith("app "):
                pass
            elif line.startswith("win "):
                name, text = _parse_name_and_text(line, "win")
                node = Node("window", name=name, text=text)
                parent.children.append(node)
                stack.append((indent, node))
            elif line == "col":
                node = Node("col")
                parent.children.append(node)
                stack.append((indent, node))
            elif line == "row":
                node = Node("row")
                parent.children.append(node)
                stack.append((indent, node))
            elif line.startswith("txt "):
                name, text = _parse_name_and_text(line, "txt")
                parent.children.append(Node("txt", name=name, text=text))
            elif line.startswith("inp "):
                name, text = _parse_name_and_text(line, "inp")
                parent.children.append(Node("inp", name=name, text=text))
            elif line.startswith("box "):
                name, text = _parse_name_and_text(line, "box")
                node = Node("box", name=name, text=text)
                parent.children.append(node)
                stack.append((indent, node))
            elif line.startswith("bar "):
                name, text = _parse_name_and_text(line, "bar")
                parent.children.append(Node("bar", name=name, text=text))
            elif line.startswith("btn "):
                left, action = (line.split(" > ", 1) + [None])[:2] if " > " in line else (line, None)
                name, text = _parse_name_and_text(left, "btn")
                parent.children.append(Node("btn", name=name, text=text, action=action.strip() if action else None))
            elif line.startswith("browser.open "):
                browser_url = _parse_quoted(line)
            else:
                # Ignore unimplemented statements in this starter.
                pass
            i += 1
        return {"preview_json": json.dumps(root.to_dict()), "browser_url": browser_url, "macros": macros}


def _parse_quoted(line: str) -> str:
    first = line.find('"')
    last = line.rfind('"')
    if first == -1 or last <= first:
        raise PythAIRRuntimeError(f"Missing quoted text in: {line}")
    return line[first + 1:last]


def _parse_name_and_text(line: str, keyword: str):
    rest = line[len(keyword):].strip()
    parts = rest.split()
    name = None
    if parts and not parts[0].startswith('"'):
        name = parts[0]
    text = _parse_quoted(line)
    return name, text
