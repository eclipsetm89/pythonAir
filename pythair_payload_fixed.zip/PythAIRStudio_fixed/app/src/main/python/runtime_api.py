from __future__ import annotations

import contextlib
import io
import json
import traceback

from air_compiler import AirLanguageUpdate1
from pythair_runtime import PythAIRParser


def _result(output: str, validation: str = "OK", preview_json: str | None = None, browser_url: str | None = None):
    return {
        "output": output,
        "validation": validation,
        "preview_json": preview_json,
        "browser_url": browser_url,
    }


def run_python(source: str):
    stdout = io.StringIO()
    stderr = io.StringIO()
    globals_dict = {
        "__name__": "__main__",
        "emit": lambda *a: print(*a),
    }
    try:
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            exec(source, globals_dict, globals_dict)
        text = stdout.getvalue()
        if stderr.getvalue():
            text += "\nSTDERR:\n" + stderr.getvalue()
        if not text.strip():
            text = "Python script finished with no output."
        return _result(text, validation="Python OK")
    except Exception:
        return _result(
            output=stdout.getvalue() + "\n" + traceback.format_exc(),
            validation="Python runtime error"
        )


def run_pythair(source: str):
    try:
        parser = PythAIRParser()
        built = parser.build_tree(source)
        validation_lines = [
            "PythAIR OK",
            f"Preview tree bytes: {len(built['preview_json'])}",
            f"Browser target: {built['browser_url'] or 'none'}",
            f"Macros: {', '.join(sorted(built['macros'])) if built['macros'] else 'none'}",
        ]
        return _result(
            output="PythAIR compiled successfully.",
            validation="\n".join(validation_lines),
            preview_json=built["preview_json"],
            browser_url=built["browser_url"],
        )
    except Exception:
        return _result(output=traceback.format_exc(), validation="PythAIR compile error")


def run_air(source: str):
    try:
        engine = AirLanguageUpdate1()
        compiled = engine.compile(source)
        validation = compiled["validation"]
        browser_url = None
        for node in compiled["ast"]:
            if node["node_type"] == "open":
                browser_url = node["data"]["value"]
                break
        output = json.dumps(compiled, indent=2)
        validation_text = json.dumps(validation, indent=2)
        return _result(output=output, validation=validation_text, browser_url=browser_url)
    except Exception:
        return _result(output=traceback.format_exc(), validation="AIR compile error")
