PythAIR Studio Minimal Buildable
================================

This is the recovery build: a smaller Android APK project designed to build more easily.

What it includes
----------------
- Real Android app project
- Kotlin + Jetpack Compose UI
- Editor tab
- Browser tab (Android WebView)
- Files tab placeholder
- Settings tab placeholder
- PythAIR branding/layout

What it does NOT include yet
----------------------------
- Embedded Python runtime
- Chaquopy
- Real PythAIR execution
- Project file picker logic

Recommended build routes
------------------------
1) Android Studio on PC
2) GitHub Actions using .github/workflows/android.yml

Termux note
-----------
This minimal project is meant to be easier than the previous one, but GitHub Actions or Android Studio is still the safer route than a full on-phone build.
