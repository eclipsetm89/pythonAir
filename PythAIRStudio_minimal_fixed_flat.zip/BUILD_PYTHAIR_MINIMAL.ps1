$ErrorActionPreference = 'Stop'
Write-Host 'Building PythAIR Studio Minimal...' -ForegroundColor Cyan

if (-not (Get-Command gradle -ErrorAction SilentlyContinue)) {
    throw 'Gradle is not installed or not on PATH.'
}

gradle wrapper --gradle-version 8.7
./gradlew.bat :app:assembleDebug --stacktrace --no-daemon
Write-Host 'Done. Check app\build\outputs\apk\debug' -ForegroundColor Green
