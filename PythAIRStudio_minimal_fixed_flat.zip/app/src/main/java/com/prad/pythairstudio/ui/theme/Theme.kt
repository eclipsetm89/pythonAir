package com.prad.pythairstudio.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val DarkColors = darkColorScheme(
    primary = NeonMint,
    onPrimary = NightBlue,
    primaryContainer = SlateCard,
    onPrimaryContainer = SoftText,
    surface = NightBlue,
    surfaceContainerLow = SlateCard,
    background = NightBlue,
    onBackground = SoftText,
    onSurface = SoftText,
    onSurfaceVariant = SoftText.copy(alpha = 0.75f)
)

private val LightColors = lightColorScheme()

@Composable
fun PythAIRStudioTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColors,
        typography = Typography,
        content = content
    )
}
