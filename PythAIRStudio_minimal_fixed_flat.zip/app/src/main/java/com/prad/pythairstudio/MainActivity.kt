package com.prad.pythairstudio

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color as ComposeColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.prad.pythairstudio.ui.theme.PythAIRStudioTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            PythAIRStudioTheme {
                AppRoot()
            }
        }
    }
}

private enum class TabItem(val label: String) {
    EDITOR("Editor"),
    BROWSER("Browser"),
    FILES("Files"),
    SETTINGS("Settings")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AppRoot() {
    var currentTab by rememberSaveable { mutableStateOf(TabItem.EDITOR) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("PythAIR Studio")
                        Text(
                            text = "Minimal buildable APK starter",
                            style = MaterialTheme.typography.labelMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar {
                val items = listOf(
                    TabItem.EDITOR to Icons.Default.Terminal,
                    TabItem.BROWSER to Icons.Default.Language,
                    TabItem.FILES to Icons.Default.Folder,
                    TabItem.SETTINGS to Icons.Default.Settings,
                )
                items.forEach { (item, icon) ->
                    NavigationBarItem(
                        selected = currentTab == item,
                        onClick = { currentTab = item },
                        icon = { Icon(icon, contentDescription = item.label) },
                        label = { Text(item.label) }
                    )
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.surface,
                            MaterialTheme.colorScheme.surfaceContainerLowest
                        )
                    )
                )
        ) {
            when (currentTab) {
                TabItem.EDITOR -> EditorScreen()
                TabItem.BROWSER -> BrowserScreen()
                TabItem.FILES -> FilesScreen()
                TabItem.SETTINGS -> SettingsScreen()
            }
        }
    }
}

@Composable
private fun EditorScreen() {
    var code by rememberSaveable {
        mutableStateOf(
            """
            app "PythAIR Demo"
            page home {
                title: "Hello from PythAIR"
                text: "This is the first minimal buildable APK shell."
                button run {
                    label: "Run later"
                }
            }
            """.trimIndent()
        )
    }
    val consoleLines = remember {
        mutableStateListOf(
            "[ready] PythAIR Studio opened.",
            "[info] This minimal APK focuses on a stable Android UI first.",
            "[next] Python/PythAIR runtime can be added in the next build."
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        HeroCard(
            title = "Editor",
            body = "Use this as your base APK. It already has the screens, browser tab, files tab, and settings tab."
        )

        OutlinedTextField(
            value = code,
            onValueChange = { code = it },
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            label = { Text("PythAIR code") },
            shape = RoundedCornerShape(18.dp)
        )

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = {
                consoleLines.add("[run] Stub run pressed. Runtime will be added in next version.")
            }) {
                Text("Run")
            }
            OutlinedButton(onClick = {
                consoleLines.add("[save] Save stub pressed.")
            }) {
                Text("Save")
            }
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text("Console", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                consoleLines.takeLast(6).forEach {
                    Text(it, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun BrowserScreen() {
    var url by rememberSaveable { mutableStateOf("https://www.example.com") }
    var pendingUrl by rememberSaveable { mutableStateOf(url) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        HeroCard(
            title = "Browser",
            body = "This uses Android WebView for the first stable APK. Later you can swap in a different backend."
        )

        OutlinedTextField(
            value = pendingUrl,
            onValueChange = { pendingUrl = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            label = { Text("Address") },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
            keyboardActions = KeyboardActions(onGo = { url = normalizeUrl(pendingUrl) })
        )

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = { url = normalizeUrl(pendingUrl) }) {
                Text("Open")
            }
            OutlinedButton(onClick = { pendingUrl = "https://www.google.com"; url = pendingUrl }) {
                Text("Google")
            }
        }

        Card(
            modifier = Modifier.fillMaxSize(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
        ) {
            AndroidView(
                modifier = Modifier.fillMaxSize(),
                factory = { context ->
                    WebView(context).apply {
                        setBackgroundColor(Color.BLACK)
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.cacheMode = WebSettings.LOAD_DEFAULT
                        webViewClient = WebViewClient()
                        webChromeClient = WebChromeClient()
                        loadUrl(url)
                    }
                },
                update = { webView ->
                    if (webView.url != url) {
                        webView.loadUrl(url)
                    }
                }
            )
        }
    }
}

@Composable
private fun FilesScreen() {
    val sampleProjects = listOf(
        "Starter Project",
        "Browser Demo",
        "UI Sandbox",
        "PythAIR Notes"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        HeroCard(
            title = "Files & Projects",
            body = "This is a UI placeholder for project browsing. Real file picking can be added after the first APK build succeeds."
        )

        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(sampleProjects) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(Icons.Default.Folder, contentDescription = null)
                        Column(modifier = Modifier.weight(1f)) {
                            Text(item, fontWeight = FontWeight.SemiBold)
                            Text(
                                "Tap later to open project actions.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen() {
    var darkWeb by rememberSaveable { mutableStateOf(true) }
    var keepScreenOn by rememberSaveable { mutableStateOf(false) }
    val notes = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(notes)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        HeroCard(
            title = "Settings",
            body = "This minimal version focuses on a stable first install. Python and PythAIR runtime integration can be layered in next."
        )

        SettingRow(
            title = "Dark browser style",
            description = "UI placeholder switch for future browser backend options.",
            checked = darkWeb,
            onCheckedChange = { darkWeb = it }
        )

        SettingRow(
            title = "Keep screen on while editing",
            description = "UI placeholder for later runtime settings.",
            checked = keepScreenOn,
            onCheckedChange = { keepScreenOn = it }
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text("What this build includes", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(8.dp))
                Text("• Editor screen")
                Text("• Browser screen")
                Text("• Files screen")
                Text("• Settings screen")
                Text("• Stable Compose UI starter")
                Text("• No Python runtime yet")
            }
        }
    }
}

@Composable
private fun HeroCard(title: String, body: String) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(body, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@Composable
private fun SettingRow(
    title: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(
                    description,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )
            }
            Switch(checked = checked, onCheckedChange = onCheckedChange)
        }
    }
}

private fun normalizeUrl(raw: String): String {
    val trimmed = raw.trim()
    return if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) trimmed
    else "https://$trimmed"
}
