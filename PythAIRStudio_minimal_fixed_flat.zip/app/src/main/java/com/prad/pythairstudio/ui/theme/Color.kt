package com.prad.pythairstudio.ui.theme

import androidx.compose.ui.graphics.Color

val NightBlue = Color(0xFF0F172A)
val NeonMint = Color(0xFF34D399)
val SlateCard = Color(0xFF1E293B)
val SoftText = Color(0xFFE2E8F0)
